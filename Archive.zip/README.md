# binance-registration-check
Check to see if registration is open on binance.com
